Here is your own personal program for fixing addresses [:

to run it you will need to open the directory in terminal,
and type "python3 main.py [FILENAME]" where [FILENAME] is the
path to the file that needs to be formatted. Also attached is
the test file and the result of the program being run on it.

If you have any inquiries or issues please let me know!
